DESTINASI NUSANTARA JAYA — WEBSITE COMPANY PROFILE

Isi folder:
- index.html : Halaman Home
- about.html : Halaman About Us
- style.css  : Desain dan pengaturan responsif
- script.js  : Interaksi menu navigasi dan tahun footer

Cara menjalankan di Visual Studio Code:
1. Ekstrak file ZIP.
2. Buka folder destinasi_nusantara_jaya di VS Code.
3. Buka index.html.
4. Jalankan menggunakan ekstensi Live Server (disarankan), atau buka index.html langsung di browser.

Sesuai ketentuan:
- Tepat dua halaman utama: Home dan About Us.
- HTML, CSS, dan JavaScript dipisahkan.
- Layout responsif untuk komputer dan HP.
- Menu navigasi dan tautan antarhalaman sudah terhubung.

Catatan:
- Foto pada halaman Home menggunakan gambar dari Unsplash dan membutuhkan koneksi internet.
- Email info@destinasinusantarajaya.example adalah alamat contoh. Ganti dengan alamat email yang benar sebelum website dipublikasikan.
- Google Fonts juga memerlukan koneksi internet; font cadangan akan digunakan jika offline.
